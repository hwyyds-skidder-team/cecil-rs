//! Native Windows PDB support (read-only).
//!
//! Scope of this module: parsing the MSF ("Compound File") container that wraps
//! every native PDB ([`msf`]), and decoding the CodeView symbol / line streams
//! inside it to map function tokens and RVAs to source files and lines
//! ([`symbols`] with [`NativePdbReader`]). Both native procedures and managed
//! IL procedures are decoded without WinAPI/DIA or an external PDB library.
//! Source checksums, full line/column ranges, locals, constants and lexical
//! scopes are available through [`FunctionDebugInfo`]. Native section offsets
//! are rebased through section-header and OMAP streams when those exist.
//! This covers MSF 7 containers and little-endian DBI/CodeView records. The
//! container reader additionally supports big-endian directory integers.
//! Legacy C11 lines, TPI/IPI type graphs, native variable location/lifetime
//! evaluation and OEM/inlining payload interpretation are not decoded.
//!
//! Reading is the only supported direction: native PDB *emission* is out of
//! scope by design; debug information is written through the portable PDB
//! format instead (see `crate::portable_writer`). Ported from
//! `Microsoft.Cci.Pdb` (PdbFileHeader, MsfDirectory, PdbReader, DataStream,
//! BitAccess, BitSet) and the CodeView readers alongside them.

pub mod msf;
pub mod symbols;

pub use symbols::{
    ConstantValue, FunctionDebugInfo, FunctionKey, NativeConstant, NativeLocal, NativePdbReader,
    NativeScope, SourceDocument, SourceLine,
};
