// pending parity wave
