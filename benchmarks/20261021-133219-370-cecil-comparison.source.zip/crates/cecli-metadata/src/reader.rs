//! `MetadataReader`: parses a complete metadata root slice and exposes heap
//! lookups plus raw cell access for every table.

use cecli_core::io::ByteReader;
use cecli_core::token::TableIndex;
use cecli_core::{Error, Result};

use crate::heaps::{BlobHeap, GuidHeap, Heaps, PdbHeap, StringHeap, UserStringHeap};
use crate::root::{parse_root, stream_slice};
use crate::tables::TableSet;

/// Read-only access to one metadata root (`BSJB` blob): heaps and tables.
///
/// The reader borrows the root slice; all returned strings, blobs, and GUIDs
/// borrow from it too.
#[derive(Debug, Clone)]
pub struct MetadataReader<'a> {
    version: String,
    heaps: Heaps<'a>,
    tables: TableSet,
    /// Payload of the `#~` stream after its header (row data only).
    table_data: &'a [u8],
}

impl<'a> MetadataReader<'a> {
    /// Parses a metadata root slice (as produced by
    /// `pe::Image::metadata_rva` on a real image).
    pub fn parse(root: &'a [u8]) -> Result<MetadataReader<'a>> {
        let header = parse_root(root)?;

        let mut strings: &[u8] = &[];
        let mut user_strings: &[u8] = &[];
        let mut blob: &[u8] = &[];
        let mut guid: &[u8] = &[];
        let mut pdb: Option<PdbHeap<'a>> = None;
        let mut table_heap: Option<&[u8]> = None;

        for stream in &header.streams {
            // Validate bounds for every declared stream, even unknown ones.
            let data = stream_slice(root, stream)?;
            match stream.name.as_str() {
                "#~" | "#-" => table_heap = Some(data),
                "#Strings" => strings = data,
                "#US" => user_strings = data,
                "#GUID" => guid = data,
                "#Blob" => blob = data,
                "#Pdb" => pdb = Some(PdbHeap::parse(data)?),
                _ => {} // Unknown streams are tolerated, like Mono.Cecil.
            }
        }

        let Some(table_data) = table_heap else {
            return Err(Error::bad_image("metadata root has no #~ stream"));
        };

        let tables = parse_table_heap(table_data, pdb.as_ref())?;
        let data_start = table_stream_data_start(table_data)?;
        let table_data = &table_data[data_start..];

        Ok(MetadataReader {
            version: header.version,
            heaps: Heaps {
                strings: StringHeap::new(strings),
                user_strings: UserStringHeap::new(user_strings),
                blob: BlobHeap::new(blob),
                guid: GuidHeap::new(guid),
                pdb,
            },
            tables,
            table_data,
        })
    }

    /// Runtime version string from the root, e.g. `"v4.0.30319"`.
    #[inline]
    pub fn version_string(&self) -> &str {
        &self.version
    }

    /// All heaps found in this root.
    #[inline]
    pub fn heaps(&self) -> &Heaps<'a> {
        &self.heaps
    }

    /// Table layout information.
    #[inline]
    pub fn tables(&self) -> &TableSet {
        &self.tables
    }

    /// Row count of `table` (0 when absent).
    #[inline]
    pub fn row_count(&self, table: TableIndex) -> u32 {
        self.tables.row_count(table)
    }

    /// Number of columns of `table` (0 when absent).
    #[inline]
    pub fn column_count(&self, table: TableIndex) -> usize {
        self.tables.column_count(table)
    }

    /// Raw cell value of column `col` in row `rid` (1-based) of `table`.
    #[inline]
    pub fn column(&self, table: TableIndex, rid: u32, col: usize) -> Result<u64> {
        let (pos, width) = self.tables.cell_location(table, rid, col)?;
        let end = pos as usize + width;
        if end > self.table_data.len() {
            return Err(Error::bad_image(format!(
                "cell [{pos}, {end}) outside #~ data of {} bytes",
                self.table_data.len()
            )));
        }
        let bytes = &self.table_data[pos as usize..end];
        Ok(match width {
            1 => u64::from(bytes[0]),
            2 => u64::from(u16::from_le_bytes([bytes[0], bytes[1]])),
            4 => u64::from(u32::from_le_bytes([bytes[0], bytes[1], bytes[2], bytes[3]])),
            8 => u64::from_le_bytes([
                bytes[0], bytes[1], bytes[2], bytes[3], bytes[4], bytes[5], bytes[6], bytes[7],
            ]),
            n => return Err(Error::bad_image(format!("unsupported cell width {n}"))),
        })
    }

    /// All cells of row `rid` (1-based) of `table`.
    pub fn row(&self, table: TableIndex, rid: u32) -> Result<Vec<u64>> {
        let count = self.column_count(table);
        (0..count).map(|col| self.column(table, rid, col)).collect()
    }

    /// Reads a known table schema into a fixed-size row without allocating.
    /// A mismatched schema size or invalid row id is an error.
    #[inline]
    pub fn row_array<const N: usize>(&self, table: TableIndex, rid: u32) -> Result<[u64; N]> {
        if self.column_count(table) != N {
            return Err(Error::argument(format!(
                "table {} has {} columns, expected {N}",
                table.name(),
                self.column_count(table)
            )));
        }
        let (start, _) = self.tables.cell_location(table, rid, 0)?;
        let row_size = self.tables.row_size(table).expect("validated table") as usize;
        let start = start as usize;
        let bytes = self.table_data.get(start..start + row_size).ok_or_else(|| {
            Error::bad_image("metadata row extends past the table stream")
        })?;
        let widths = self.tables.row_widths(table).expect("validated table");
        let mut row = [0; N];
        let mut offset = 0;
        for (cell, &width) in row.iter_mut().zip(widths) {
            *cell = match width {
                1 => u64::from(bytes[offset]),
                2 => u64::from(u16::from_le_bytes([bytes[offset], bytes[offset + 1]])),
                4 => u64::from(u32::from_le_bytes([
                    bytes[offset], bytes[offset + 1], bytes[offset + 2], bytes[offset + 3],
                ])),
                _ => unreachable!("metadata schemas have only 1, 2 or 4 byte cells"),
            };
            offset += width as usize;
        }
        Ok(row)
    }
}

/// Reads the `#~` header and computes the table layout. Pdb-heap row counts
/// are applied first, exactly like Mono.Cecil's `ReadTableHeap`; counts then
/// present in the `#~` stream itself override them.
fn parse_table_heap(heap: &[u8], pdb: Option<&PdbHeap>) -> Result<TableSet> {
    let mut r = ByteReader::new(heap);
    let _reserved = r.u32()?;
    let major = r.u8()?;
    let minor = r.u8()?;
    // .NET 1.x images use table-stream version 1.x; 2.0 is the modern form.
    // Cecil accepts both, so we do too.
    if major != 1 && major != 2 {
        return Err(Error::unsupported(format!(
            "unsupported table stream version {major}.{minor}"
        )));
    }
    let heap_flags = r.u8()?;
    let _reserved2 = r.u8()?;
    let valid = r.u64()?;
    let _sorted = r.u64()?;

    let mut counts = [0u32; crate::tables::TABLE_COUNT];
    if let Some(p) = pdb {
        for (i, count) in counts.iter_mut().enumerate() {
            if let Some(t) = TableIndex::from_u8(i as u8) {
                *count = p.row_count(t);
            }
        }
    }
    for (i, count) in counts.iter_mut().enumerate() {
        if valid >> i & 1 == 0 {
            continue;
        }
        *count = r.u32()?;
    }

    let set = TableSet::compute_checked(valid, &counts, heap_flags)?;

    // Declared row counts must physically fit in the stream: the total table
    // extent (header consumed above) may not overrun the heap. Without this
    // a hostile header can declare millions of phantom rows, which readers
    // turn into per-row allocations before any column read fails.
    let data_start = table_stream_data_start(heap)? as u64;
    let extent = set.tables_extent();
    if data_start + extent > heap.len() as u64 {
        return Err(Error::bad_image(format!(
            "metadata tables ({extent} bytes) overrun the #~ stream ({} bytes of data)",
            heap.len() as u64 - data_start
        )));
    }
    Ok(set)
}

/// Size of the `#~` header including the per-table row-count array; the row
/// data begins there.
fn table_stream_data_start(heap: &[u8]) -> Result<usize> {
    let mut r = ByteReader::new(heap);
    let _reserved = r.u32()?;
    let _major = r.u8()?;
    let _minor = r.u8()?;
    let _heap_flags = r.u8()?;
    let _reserved2 = r.u8()?;
    let valid = r.u64()?;
    let mut pos = 24;
    for i in 0..64 {
        if valid >> i & 1 == 0 {
            continue;
        }
        pos += 4;
    }
    Ok(pos)
}
